<?php

namespace KarcherBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class MensajesControllerTest extends WebTestCase
{
}
