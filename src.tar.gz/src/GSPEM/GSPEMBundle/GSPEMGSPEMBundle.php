<?php

namespace GSPEM\GSPEMBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class GSPEMGSPEMBundle extends Bundle
{
}
