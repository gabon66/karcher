<?php

namespace GSPEM\GSPEMBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class StockAltaControllerTest extends WebTestCase
{
}
