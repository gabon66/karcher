<?php

namespace GSPEM\GSPEMBundle\Entity;

/**
 * Test
 */
class Test
{
    /**
     * @var int
     */
    private $id;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }
}
