<?php

namespace GSPEM\SecurityBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class GSPEMSecurityBundle extends Bundle
{
}
