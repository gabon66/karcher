ngBarcode
==============

An AngularJS directive that creates code39 barcodes based on the Antonello Pasella's [jquery-barcode plugin](https://github.com/antonellopasella/jquery-barcode).

# Demo

Try ng-barcode using this [online demo](http://luigiquarta.github.io/ng-barcode/).

# Usage

```sh
$ npm install ng-barcode
```

