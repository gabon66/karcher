/**
 * Created by gabo on 26/07/16.
 */


GSPEMApp.controller('ordersControl', function($scope,$http,$uibModal,toastr,MovPend) {


});
