<?php

namespace KarcherBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class KarcherBundle extends Bundle
{
}
